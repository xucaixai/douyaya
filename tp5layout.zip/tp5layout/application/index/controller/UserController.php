<?php

namespace app\index\controller;

use think\Controller;

class UserController extends Controller
{
    public function author()
    {
        return $this->fetch();
    }
    public function login()
    {
        return $this->fetch();
    }
    public function register()
    {
        return $this->fetch();
    }
}